This .reg script will set Media player 2 (classic) as default audio player  for .wav files.
This should fix the sound issues that sometimes appear in Internet Explorer, after installing other browsers
		(Netscape or Firefox) or IE plugins, especially after installin iTunes player (also known as QuickTime for Mac).
Do not run it if you don't have any sound issues in chat.
If your clients claim they have trouble when "Welcome sound" and/or "Room notify sound on entrance" are enabled
		(the chat freezes or they get booted from the room without hearing any sound, also buzz sounds hearing/page lock-ups),
		send them this .reg file and tell them to run it and accept it.