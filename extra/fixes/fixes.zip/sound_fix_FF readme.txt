Extract & put the 3 dlls into your Mozilla/Firefox/plugins folder (or any Gecko browser that requires mplayer2 plugins).
Restart the browser and enjoy!